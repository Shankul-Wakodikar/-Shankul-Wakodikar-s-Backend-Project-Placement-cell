const developement = {
    name :'developement',
    db_path :'./config/mongoose',
    passport_path : './config/passport-local-strategy',
    customMware_path : './config/flashMessage',
    assets_path : './assets',
    secret_key :'#placementCell@careercamp$$Team&&&interface##Amit^^Singh%%',
    mongoose_path :'mongodb+srv://placement:1UbhMXi13RXuCwSn@cluster0.p5gbb.mongodb.net/placementcell?retryWrites=true&w=majority',
    api_path :'https://remotive.com/api/remote-jobs'
}
module.exports = developement;